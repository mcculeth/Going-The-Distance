function SOLUTION(){
let x1 = document.getElementById("x1").value;
let y1 = document.getElementById("y1").value;
let x2 = document.getElementById("x2").value;
let y2 = document.getElementById("y2").value;

let minusx = (x2 - x1);
let minusy = (y2 - y1);

let power = Math.pow(minusx, 2);
let power2 = Math.pow(minusy, 2);

let adding = (parseInt(power,10) + parseInt(power2,10));
let truef = Math.sqrt(adding);
let finaldis = Math.round(truef);


document.getElementById("myForm").innerHTML = "<h3>The distance between both points is <span class='solution'>" + finaldis + "</span></h3>";
}