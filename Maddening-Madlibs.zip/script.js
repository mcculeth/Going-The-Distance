function madStart(){
noun1 =document.getElementById("noun1").value;
noun2 =document.getElementById("noun2").value;
noun3 =document.getElementById("noun3").value;
adj1 =document.getElementById("adj1").value;
adj2 =document.getElementById("adj2").value;
adj3 =document.getElementById("adj3").value;
username =document.getElementById("username").value;
 
document.getElementById("MADLIB").innerHTML ="<p> Who cares about " + noun1 + " it's completely irrelevant, " + noun1 + " is so " + adj1 + " . It's " + adj1 + " that i can't go to MacDonald. Is it because i'm " + adj2 + " and " + adj3 + " ? In the end i'm honestly not that bright, my name is " + username + " after all. Maybe I should reconsider my liking of " + noun1 + " . That could also explain why I like " + noun2 + " and " + noun3 + " , since i'm so incompetent. </p> <br> <br> <p> please refresh to resubmit. </p>"
}